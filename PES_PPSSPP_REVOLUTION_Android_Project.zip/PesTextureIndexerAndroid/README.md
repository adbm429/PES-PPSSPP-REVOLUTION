# PES PPSSPP Revolution Android

Proyek Android berbasis WebView untuk prototype HTML PES PPSSPP Revolution.

- `minSdk 21`: Android 5.0 atau lebih baru (kompatibilitas tetap bergantung pada perangkat/WebView).
- Memilih gambar memakai pemilih file Android.
- Ekspor PNG/BMP disimpan ke `Download/PES PPSSPP Revolution/`.
- APK debug ditandatangani otomatis dengan debug key oleh Gradle, sehingga dapat dipasang untuk penggunaan/pengujian pribadi.

## Membuat APK dengan Android Studio
1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Membuat APK lewat GitHub Actions
Workflow tersedia di `.github/workflows/build-apk.yml`.
1. Unggah isi folder proyek ini sebagai repository GitHub baru.
2. Buka tab **Actions** dan jalankan **Build PES PPSSPP Revolution APK** (Run workflow), atau push ke branch `main`/`master`.
3. Setelah proses sukses, buka hasil run workflow dan unduh artifact **PES-PPSSPP-REVOLUTION-APK**.
4. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di perangkat Android. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

Catatan: APK debug cocok untuk instalasi langsung dan pengujian; distribusi publik sebaiknya menggunakan APK release yang ditandatangani dengan keystore milik sendiri.
